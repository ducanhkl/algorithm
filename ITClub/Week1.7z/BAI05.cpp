#include <bits/stdc++.h>
#define mp make_pair
#define pii pair<long long, long long>
#define priority_queue pq
#define ll long long
#define maxnum 123456789

using namespace std;

double x, y, z, k;

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(NULL);
	cin >> x >> y >> z;
	k = sqrt(x*y*z);
	cout << k/x + k/y + k/z;
	return 0;
}
