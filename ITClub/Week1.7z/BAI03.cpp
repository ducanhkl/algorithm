#include <bits/stdc++.h>

using namespace std;

int main(float x)
{
    cin >> x, cout << 2*x*3.14 << endl << x*x*3.14;
}
