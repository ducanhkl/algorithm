#include <bits/stdc++.h>
using namespace std;

int a;
long long b;
char c;
float f;
double d;

int main()
{
    cin >> a >> b >> c>> f >> d;
    cout << a << endl << b << endl << c << endl;
    cout << fixed << setprecision(3) << f << endl;
    cout << fixed << setprecision(9) << d << endl;
}
