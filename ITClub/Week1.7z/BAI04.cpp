#include <bits/stdc++.h>
#define mp make_pair
#define pii pair<long long, long long>
#define priority_queue pq
#define ll long long
#define maxnum 123456789

using namespace std;

double x;

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(NULL);
	cin >> x;
	cout << x*x*1.14;
	return 0;
}
