#include <bits/stdc++.h>
#define mp make_pair
#define pii pair<long long, long long>
#define priority_queue pq
#define ll long long
#define maxnum 123456789

using namespace std;
ll a, b, c, m1, max1, max2;

int main()
{
	ios_base::sync_with_stdio(0), cin.tie(NULL);
	cin >> a >> b >> c;
	max1 = (a+b+abs(a-b))/2;
	max2 = (a+c+abs(a-c))/2;
	cout << (max1 + max2 + abs(max2-max1))/2;
	return 0;
}
